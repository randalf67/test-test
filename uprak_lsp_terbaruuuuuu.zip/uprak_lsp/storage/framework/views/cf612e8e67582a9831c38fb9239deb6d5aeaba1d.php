<nav class="navbar navbar-light" style="background-color: #0000D1;">
    <div class="container-fluid ">
      <a class="navbar-brand text-light fw-bold fs-3" href="/">
        Pengaduan Siswa
      </a>

      <div class="">
      <a class="navbar-brand text-light fst-normal-4" href="/aspirasi" >
        <i class="bi bi-envelope-fill d-inline-block align-text-top "></i>
        Aspirasi
      </a>
      <a class="navbar-brand text-light fst-normal-4" href="/list" >
        <i class="bi bi-clipboard-data d-inline-block align-text-top "></i>
        List Pengaduan
      </a>
      <a class="navbar-brand text-light fst-normal-4" href="" data-bs-toggle="modal" data-bs-target="#exampleModal" >
      <button type="submit" class="btn btn-sm btn-outline-success fst-normal-4" ><i class="bi bi-door-open-fill d-inline-block align-text-top "></i></button>
        
      </a>
      </div>

    </div>
  </nav>
  <div class="container">  <?php if(session()->has('LoginError')): ?>
    <div class="alert alert-danger my-3 alert-dismissible fade show" role="alert">
      <?php echo e(session('LoginError')); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?></div>
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Login Admin</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="/login" method="post">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <label for="recipient-name" class="col-form-label">Username</label>
              <input type="text" value="<?php echo e(old('username')); ?>" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autofocus name="username" id="recipient-name">
              <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
              <label for="message-text" class="col-form-label">Password:</label>
              <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autofocus name="password" id="">
              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
       
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-outline-primary">Login</button>
        </form>
        </div>
      </div>
    </div>
  </div>
<?php /**PATH C:\xampp\htdocs\uprak_lsp\resources\views/partials/navbar.blade.php ENDPATH**/ ?>