@extends('layouts.main')
@section('container')
<div class="row">
<h1 class="fw-bold mb-2" align="center">Layanan Pengaduan Siswa</h1>
<a>
  <br>
</a>
<div id="carouselExampleAutoplaying" class="carousel slide carousel-fade" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="{{ asset('img/pengaduan_siswa.jpg') }}" class="d-block" alt="..." height="600" width="100%">
    </div>
    <div class="carousel-item">
      <img src="{{ asset('img/4.jpg') }}" class="d-block" alt="..." height="600" width="100%">
    </div>
    <div class="carousel-item">
      <img src="{{ asset('img/5.jpg') }}" class="d-block" alt="..." height="600" width="100%">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
    </div>
    <a>
      <br>
    </a>
    <div class="col-12">
            <Article>
                <p>Pada website ini kami menerima kelah kesuh siswa dalam area sekolah</p>
                <p>Segala laporan yang diterima akan kami sampaikan kepada pihak sekolah dan segera diatasi dengan cepat dan baik </p>
                <p>tetaplah bersemangat dalam belajar dan SEMANGAT UJIAN</p>
            </Article>
      
    </div>
</div>
@endsection
